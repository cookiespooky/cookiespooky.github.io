---
type: redirect
slug: linguistic-laboratory-landing
title: Ты уже решаешь свои проблемы - legacy
description: "Старая страница перенесена. Актуальная версия: diagnostic-session."
draft: false
noindex: true
redirect_to: /diagnostic-session/
canonical_slug: diagnostic-session
legacy_from_old_site: true
---
Актуальная страница: [[diagnostic-session|LAT-сессия: анализ речи, позиции и следующего шага]].
